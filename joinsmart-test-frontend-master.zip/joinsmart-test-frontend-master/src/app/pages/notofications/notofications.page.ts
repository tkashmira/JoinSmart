import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-notofications',
  templateUrl: './notofications.page.html',
  styleUrls: ['./notofications.page.scss'],
})
export class NotoficationsPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
