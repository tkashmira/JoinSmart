export class AuthConstants {
    public static readonly AUTH = 'userData';
    public static readonly TOKEN = 'token';
    };